- Danh mục bài tập bao gồm: (Các bài tập sử dụng ma trận kề)
    + 8. Tìm vùng nhiều số 1 nhất