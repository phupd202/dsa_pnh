- Danh mục bài tập (Các bài tập sử dụng danh sách kề)
    + 1. In danh sách kề của đồ thị: PrintAdjList
    + 3. Duyệt dfs
    + 4. Duyệt bfs
    + 5. Tìm chu trình trên đồ thị vô hướng
    + 7. Đếm số đảo
    + 11. Kiểm tra đường đi nối 2 điểm
    + 13. Bậc của nút